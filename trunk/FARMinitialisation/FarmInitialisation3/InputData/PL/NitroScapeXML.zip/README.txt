This archive was created by Datum on Wednesday 8th of December 2010 10:13:49 AM.
It contains data (Farm management data ) for the landscapes Turew-Wyskoć and the years 2007, 2008, 2009.

End
===
The files has been generated in 3.062 seconds.